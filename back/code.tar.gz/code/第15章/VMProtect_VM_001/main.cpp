#include <Windows.h>

using namespace std;

int __declspec(dllexport) main()
{
    LoadResource()
    DebugBreak();
    __asm mov eax,012345678h
    return 0;
}

