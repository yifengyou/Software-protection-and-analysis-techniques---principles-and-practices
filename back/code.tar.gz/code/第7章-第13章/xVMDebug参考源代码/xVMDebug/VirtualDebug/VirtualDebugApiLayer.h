#ifndef VIRTUALDEBUGAPILAYER_H
#define VIRTUALDEBUGAPILAYER_H

BOOL	InstallVirtualDebugLayer();
BOOL    UnInstallVirtualDebugLayer();
extern s_mm_dbg_event	gstdbg;

#endif //VIRTUALDEBUGAPILAYER_H
