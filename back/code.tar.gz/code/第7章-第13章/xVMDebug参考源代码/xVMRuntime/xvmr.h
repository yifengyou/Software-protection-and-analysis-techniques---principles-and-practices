#ifndef xvmr_h__
#define xvmr_h__

class NPipeClient;
extern NPipeClient* gAlertPipe;
#endif // xvmr_h__
